package com.example.evolutiongame;

import android.content.Context;
import android.media.Image;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.ImageView;

//卡片类（小方格）
public class Card extends FrameLayout {

    private int num = 0;//卡片上的数

//    private TextView label;
    private ImageView img;

    public Card(Context context) {
        super(context);
//        label = new TextView(getContext());
//        label.setTextSize(32);
//        label.setGravity(Gravity.CENTER);

        img = new ImageView(getContext());

        LayoutParams lp = new LayoutParams(-1, -1);
        lp.setMargins(10, 10, 0, 0);

//        addView(label, lp);
        addView(img,lp);

        setNum(0);
    }

    public int getNum() {
        return num;
    }

    //设置卡片上的数
    public void setNum(int num) {

        //设置数的大小
        this.num = num;
        if (num > 0) {
            img.setImageResource(R.drawable.dna);
        } else {
            img.setImageBitmap(null);   //overwrite?
            img.setBackgroundColor(0xffccc0b2);

        }

        //根据数值大小改变卡片的背景颜色
        switch (num) {
            case 0:
                img.setImageBitmap(null);
                img.setBackgroundColor(0xffeeeae5);
                break;
            case 2:
                img.setImageResource(R.drawable.dna);
                break;
            case 4:
                img.setImageResource(R.drawable.cell);
                break;
            case 8:
                img.setImageResource(R.drawable.fungus);
                break;
            case 16:
                img.setImageResource(R.drawable.shellfish);
                break;
            case 32:
                img.setImageResource(R.drawable.fish);
                break;
            case 64:
                img.setImageResource(R.drawable.lizard);
                break;
            case 128:
                img.setImageResource(R.drawable.mouse);
                break;
            case 256:
                img.setImageResource(R.drawable.rabbit);
                break;
            case 512:
                img.setImageResource(R.drawable.champ);
                break;
            case 1024:
                img.setImageResource(R.drawable.human);
                break;
            default:
                img.setBackgroundColor(0xffedc22d);
                break;
        }

    }

    //判断两个卡片上的数值是否相等
    public boolean equals(Card card) {
        return getNum() == card.getNum();
    }

    public ImageView getImgView() {return img;}
}
